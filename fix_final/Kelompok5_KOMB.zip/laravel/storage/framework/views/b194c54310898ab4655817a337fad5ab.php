<div class="bg-white rounded-[32px] shadow-2xl flex flex-col max-h-[85vh]">

    <div class="flex-shrink-0 flex items-center justify-between px-8 py-5 border-b border-gray-100 bg-white rounded-t-[32px] z-[60]">
        <div class="flex items-center gap-4">
            <a href="<?php echo e(route('user.profile', ['username' => $shot->user->username ?? ''])); ?>" class="block">
                <div class="relative">
                    <img src="<?php echo e($shot->user->avatar_url ?? 'https://ui-avatars.com/api/?name=' . urlencode($shot->user->full_name ?? $shot->user->username ?? 'U')); ?>"
                        alt="<?php echo e($shot->user->username ?? 'User'); ?>"
                        class="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm">
                </div>
            </a>

            <div>
                <a href="<?php echo e(route('user.profile', ['username' => $shot->user->username ?? ''])); ?>" class="block">
                    <h3 class="font-bold text-gray-900 text-base leading-tight">
                        <?php echo e($shot->user->username ?? 'Unknown User'); ?>

                    </h3>
                </a>
            </div>

            <?php if(auth()->guard()->check()): ?>
            <?php if($shot->user && auth()->id() !== $shot->user_id): ?>
            <button
                onclick="followUser(<?php echo e($shot->user_id); ?>, this)"
                class="ml-3 text-gray-500 hover:text-gray-900 font-medium text-sm transition">
                <?php echo e($shot->isFollowedBy(auth()->user()) ? 'Following' : 'Follow'); ?>

            </button>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="flex items-center gap-3">
            <button
                type="button"
                onclick="likeShotModal(<?php echo e($shot->id); ?>, this)"
                class="modal-like-button group w-11 h-11 rounded-full border border-gray-200 hover:border-pink-300 hover:bg-pink-50 flex items-center justify-center transition-all <?php echo e(auth()->check() && $shot->isLikedBy(auth()->user()) ? 'text-[#ea4c89]' : 'text-gray-600'); ?>">
                <svg
                    class="w-5 h-5 transition modal-like-svg <?php echo e(auth()->check() && $shot->isLikedBy(auth()->user()) ? 'text-[#ea4c89]' : 'text-gray-600'); ?>"
                    fill="<?php echo e(auth()->check() && $shot->isLikedBy(auth()->user()) ? 'currentColor' : 'none'); ?>"
                    stroke="currentColor"
                    viewBox="0 0 24 24">

                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z">
                    </path>
                </svg>
            </button>

            <button
                onclick="saveShotModal(<?php echo e($shot->id); ?>, this)"
                class="group w-11 h-11 rounded-full border border-gray-200 hover:border-gray-400 hover:bg-gray-50 flex items-center justify-center transition-all">
                <svg class="w-5 h-5 text-gray-600 group-hover:text-gray-900 transition"
                    fill="<?php echo e(auth()->check() && $shot->isSavedBy(auth()->user()) ? 'currentColor' : 'none'); ?>"
                    stroke="currentColor"
                    viewBox="0 0 24 24">
                    <path stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z">
                    </path>
                </svg>
            </button>

            <?php if(auth()->guard()->check()): ?>
            <button
                type="button"
                onclick="openGetInTouchModal(<?php echo e($shot->id); ?>)"
                class="bg-[#0d0c22] text-white px-6 py-2.5 rounded-full font-semibold hover:bg-gray-800 transition shadow-lg">
                Get in touch
            </button>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="bg-[#0d0c22] text-white px-6 py-2.5 rounded-full font-semibold hover:bg-gray-800 transition shadow-lg">
                Get in touch
            </a>
            <?php endif; ?>

            
            <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->id() === $shot->user_id): ?>
            <form action="<?php echo e(route('shots.destroy', $shot->id)); ?>" method="POST" onsubmit="return confirm('Apakah kamu yakin ingin menghapus postingan ini?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded-full font-semibold hover:bg-red-600 transition text-sm shadow-md">
                    Delete
                </button>
            </form>
            <?php endif; ?>
            <?php endif; ?>
            <button @click="closeModal()" class="ml-2 w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center transition">
                <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
    </div>

    <div class="overflow-y-auto p-8 rounded-b-[32px]">
        <h2 class="text-4xl font-bold text-gray-900 mb-6">
            <?php echo e($shot->title); ?>

        </h2>

        <div class="relative bg-[#c8d8b8] rounded-[24px] overflow-hidden mb-8">
            <img src="<?php echo e(\Illuminate\Support\Str::startsWith($shot->image_url, 'http') ? $shot->image_url : asset('storage/' . $shot->image_url)); ?>"
                alt="<?php echo e($shot->title); ?>"
                class="w-full h-auto object-cover">
        </div>

        <?php if($shot->description): ?>
        <p class="text-gray-600 text-lg mb-8 max-w-3xl whitespace-pre-line">
            <?php echo e($shot->description); ?>

        </p>
        <?php endif; ?>

        <?php if($shot->categories && $shot->categories->count()): ?>
        <div class="flex flex-wrap gap-2 mb-8">
            <?php $__currentLoopData = $shot->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="px-4 py-1.5 bg-gray-100 rounded-full text-sm text-gray-600 font-medium">
                <?php echo e($category->name); ?>

            </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <div class="flex items-center justify-between pt-6 border-t border-gray-100">
            <div class="flex items-center gap-6">
                <div class="flex items-center gap-2 text-gray-500">
                    <svg
                        id="modal-bottom-like-icon-<?php echo e($shot->id); ?>"
                        class="w-5 h-5 modal-like-icon <?php echo e(auth()->check() && $shot->isLikedBy(auth()->user()) ? 'text-[#ea4c89]' : 'text-gray-500'); ?>"
                        fill="<?php echo e(auth()->check() && $shot->isLikedBy(auth()->user()) ? 'currentColor' : 'none'); ?>"
                        viewBox="0 0 24 24">
                        <path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                    </svg>

                    <span
                        id="modal-like-count-<?php echo e($shot->id); ?>"
                        data-shot-id="<?php echo e($shot->id); ?>"
                        class="like-count font-medium">
                        <?php echo e($shot->likes_count ?? 0); ?>

                    </span>
                </div>
            </div>
        </div>

        <div id="comments-section-<?php echo e($shot->id); ?>" class="mt-8 pt-8 border-t border-gray-100 bg-white">
            <h3 class="text-2xl font-bold text-gray-900 mb-6">
                Comments
            </h3>

            <div id="comments-list-<?php echo e($shot->id); ?>" class="space-y-5">
                <?php $__empty_1 = true; $__currentLoopData = $shot->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="flex gap-3">
                    <img
                        src="<?php echo e($comment->user->avatar_url ?? 'https://ui-avatars.com/api/?name=' . urlencode($comment->user->full_name ?? $comment->user->username ?? 'U')); ?>"
                        class="w-10 h-10 rounded-full object-cover">

                    <div>
                        <div class="flex items-center gap-2">
                            <h4 class="font-semibold text-gray-900">
                                <?php echo e($comment->user->username); ?>

                            </h4>

                            <span class="text-xs text-gray-400">
                                <?php echo e($comment->created_at->diffForHumans()); ?>

                            </span>
                        </div>

                        <p class="text-gray-600 text-sm mt-1">
                            <?php echo e($comment->body); ?>

                        </p>
                        <?php if(auth()->guard()->check()): ?>
                        <button
                            type="button"
                            onclick="prepareReply('<?php echo e($comment->user->username); ?>', '<?php echo e($shot->id); ?>')"
                            class="text-xs text-gray-400 hover:text-gray-900 font-semibold mt-1.5 transition block">
                            Reply
                        </button>
                        <?php endif; ?>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div id="empty-comments-<?php echo e($shot->id); ?>" class="text-gray-400 text-sm">
                    Belum ada komentar. Jadilah yang pertama komentar.
                </div>

                <?php endif; ?>
            </div>

            <?php if(auth()->guard()->check()): ?>
            <form
                class="mt-6 flex gap-3"
                onsubmit="commentShotModal(event, <?php echo e($shot->id); ?>, this)">
                <img
                    src="<?php echo e(auth()->user()->avatar_url ?? 'https://ui-avatars.com/api/?name=' . urlencode(auth()->user()->full_name ?? auth()->user()->username ?? 'U')); ?>"
                    class="w-10 h-10 rounded-full object-cover">

                <div class="flex-1">
                    <textarea
                        name="body"
                        rows="3"
                        placeholder="Tulis komentar..."
                        class="w-full rounded-2xl border border-gray-200 focus:border-gray-400 focus:ring-0 text-sm resize-none text-gray-900 bg-white"
                        required></textarea>

                    <div class="flex justify-end mt-2">
                        <button
                            type="submit"
                            class="px-5 py-2 rounded-full bg-[#0d0c22] text-white text-sm font-semibold hover:bg-gray-800 transition">
                            Comment
                        </button>
                    </div>
                </div>
            </form>
            <?php else: ?>
            <div class="mt-6 text-sm text-gray-500">
                <a href="<?php echo e(route('login')); ?>" class="font-semibold text-[#ea4c89]">
                    Login
                </a>
                untuk menulis komentar.
            </div>
            <?php endif; ?>
        </div>

    </div>
</div>

<div class="fixed right-8 top-1/2 -translate-y-1/2 flex flex-col gap-3 z-[110]">
    <button
        type="button"
        onclick="document.getElementById('comments-section-<?php echo e($shot->id); ?>')?.scrollIntoView({ behavior: 'smooth', block: 'start' })"
        class="group relative w-12 h-12 bg-white rounded-full shadow-lg border border-gray-200 hover:border-gray-400 flex items-center justify-center transition-all">
        <svg class="w-5 h-5 text-gray-600 group-hover:text-gray-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
        </svg>
    </button>

    <button class="group w-12 h-12 bg-white rounded-full shadow-lg border border-gray-200 hover:border-gray-400 flex items-center justify-center transition-all">
        <svg class="w-5 h-5 text-gray-600 group-hover:text-gray-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"></path>
        </svg>
    </button>

    <button class="group w-12 h-12 bg-white rounded-full shadow-lg border border-gray-200 hover:border-gray-400 flex items-center justify-center transition-all">
        <svg class="w-5 h-5 text-gray-600 group-hover:text-gray-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
        </svg>
    </button>
</div>

<?php if(auth()->guard()->check()): ?>
<div
    id="get-in-touch-modal-<?php echo e($shot->id); ?>"
    class="fixed inset-0 z-[300] hidden items-center justify-center bg-black/50 backdrop-blur-sm px-4">
    <div class="bg-white w-full max-w-md rounded-[28px] shadow-2xl p-7 relative">

        <button
            type="button"
            onclick="closeGetInTouchModal(<?php echo e($shot->id); ?>)"
            class="absolute top-5 right-5 text-gray-400 hover:text-gray-700 transition text-xl">
            ×
        </button>

        <div class="flex items-center gap-4 mb-6">
            <img
                src="<?php echo e($shot->user->avatar_url ?? 'https://ui-avatars.com/api/?name=' . urlencode($shot->user->full_name ?? $shot->user->username ?? 'U')); ?>"
                class="w-14 h-14 rounded-full object-cover border border-gray-200">

            <div>
                <h3 class="text-xl font-bold text-[#0d0c22]">
                    Connect with <?php echo e($shot->user->username ?? 'Designer'); ?>

                </h3>

                <p class="text-xs text-gray-500 mt-1">
                    Responds within a few days
                </p>
            </div>
        </div>

        <div class="flex items-center gap-3 mb-6">
            <button
                type="button"
                class="px-4 py-2 rounded-full bg-gray-100 text-[#0d0c22] text-sm font-semibold">
                Message
            </button>
        </div>

        <div id="message-content-<?php echo e($shot->id); ?>">
            <form
                id="form-get-in-touch-<?php echo e($shot->id); ?>"
                action="<?php echo e(route('project.inquiry.store', $shot->id)); ?>"
                method="POST"
                onsubmit="sendGetInTouchMessage(event, <?php echo e($shot->id); ?>, this)"
                data-designer-email="<?php echo e($shot->user->email); ?>"
                data-designer-username="<?php echo e($shot->user->username); ?>"
                data-shot-title="<?php echo e($shot->title); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-5">
                    <label class="flex items-center justify-between text-sm font-semibold text-[#0d0c22] mb-2">
                        <span>Project Details <span class="text-pink-500">*</span></span>
                        <span class="text-xs text-gray-400">Minimum 50 characters</span>
                    </label>

                    <textarea
                        name="message"
                        rows="6"
                        minlength="50"
                        required
                        placeholder="Include any project details, requirements, or goals..."
                        class="w-full rounded-2xl border border-gray-200 focus:border-pink-400 focus:ring-pink-400 text-sm resize-none text-gray-900"></textarea>
                </div>

                <div class="mb-5">
                    <label class="block text-sm font-semibold text-[#0d0c22] mb-2">
                        Target Date <span class="text-pink-500">*</span>
                    </label>

                    <select
                        name="target_date"
                        required
                        class="w-full rounded-2xl border border-gray-200 focus:border-pink-400 focus:ring-pink-400 text-sm text-gray-700">
                        <option value="">Please select...</option>
                        <option value="ASAP">As soon as possible</option>
                        <option value="1-2 weeks">1–2 weeks</option>
                        <option value="1 month">Within 1 month</option>
                        <option value="flexible">Flexible</option>
                    </select>
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-semibold text-[#0d0c22] mb-2">
                        Project Budget <span class="text-pink-500">*</span>
                    </label>

                    <div class="relative">
                        <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                            Rp
                        </span>

                        <input
                            type="number"
                            name="budget"
                            required
                            min="0"
                            placeholder="Enter amount"
                            class="w-full rounded-2xl border border-gray-200 focus:border-pink-400 focus:ring-pink-400 text-sm pl-12 text-gray-900">
                    </div>

                    <label class="flex items-center gap-2 mt-3 text-xs text-gray-600">
                        <input
                            type="checkbox"
                            name="recommend_budget"
                            class="rounded border-gray-300 text-pink-500 focus:ring-pink-500">
                        Let designer recommend a budget
                    </label>
                </div>

                <div class="mb-5">
                    <label class="block text-sm font-bold text-gray-700 mb-2">Contact Person</label>
                    <input
                        type="text"
                        name="contact_person"
                        placeholder="phone number or email"
                        class="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-pink-500 transition"
                        required>
                </div>

                <button
                    type="button"
                    onclick="sendGetInTouchMessage(event, <?php echo e($shot->id); ?>, document.getElementById('form-get-in-touch-<?php echo e($shot->id); ?>'))"
                    class="w-full h-12 rounded-full bg-[#ea4c89] hover:bg-[#c73e72] text-white font-bold transition">
                    Send Message
                </button>

            </form>
        </div>
    </div>


</div>
</div>
<?php endif; ?>
<script>
    function prepareReply(username, shotId) {
        const form = document.querySelector(`form[onsubmit*="${shotId}"]`);
        if (!form) return;
        const textarea = form.querySelector('textarea[name="body"]');
        if (!textarea) return;
        textarea.value = `@${username} ` + textarea.value;
        textarea.focus();
        form.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
    }

    function sendGetInTouchMessage(event, shotId, formElement) {
        event.preventDefault();
        const url = formElement.getAttribute('action');
        const formData = new FormData(formElement);

        fetch(url, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': formElement.querySelector('input[name="_token"]').value
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);

                    formElement.reset();

                    closeGetInTouchModal(shotId);
                } else {
                    alert('Terjadi kesalahan, silakan coba lagi.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Gagal mengirim pesan. Pastikan detail proyek minimal 50 karakter.');
            });
    }

    function sendGetInTouchMessage(event, shotId, formElement) {
        event.preventDefault();

        if (!formElement) {
            alert('Form tidak ditemukan!');
            return;
        }

        const url = formElement.getAttribute('action');
        const formData = new FormData(formElement);

        fetch(url, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': formElement.querySelector('input[name="_token"]').value
                },
                body: formData
            })
            .then(async response => {
                const data = await response.json();

                if (response.ok && data.success) {
                    alert(data.message);
                    formElement.reset();
                    closeGetInTouchModal(shotId);
                } else {
                    if (data.errors) {
                        const errorMessages = Object.values(data.errors).flat().join('\n');
                        alert('Gagal:\n' + errorMessages);
                    } else {
                        alert('Gagal: ' + (data.message || 'Terjadi kesalahan.'));
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Koneksi gagal atau ada error di Controller kamu.');
            });
    }
</script><?php /**PATH D:\tubesPWL\TUBES-PWL---5\fix_final\laravel\resources\views/partials/shot_modal_content.blade.php ENDPATH**/ ?>