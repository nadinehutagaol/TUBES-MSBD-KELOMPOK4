<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CategoriesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('categories')->delete();
        
        \DB::table('categories')->insert(array (
            0 => 
            array (
                'id' => 2,
                'name' => 'animation',
            ),
            1 => 
            array (
                'id' => 3,
                'name' => 'branding',
            ),
            2 => 
            array (
                'id' => 1,
                'name' => 'discover',
            ),
            3 => 
            array (
                'id' => 4,
                'name' => 'illustration',
            ),
            4 => 
            array (
                'id' => 5,
                'name' => 'mobile',
            ),
            5 => 
            array (
                'id' => 6,
                'name' => 'print',
            ),
            6 => 
            array (
                'id' => 7,
                'name' => 'product-design',
            ),
            7 => 
            array (
                'id' => 8,
                'name' => 'typography',
            ),
            8 => 
            array (
                'id' => 9,
                'name' => 'web-design',
            ),
        ));
        
        
    }
}