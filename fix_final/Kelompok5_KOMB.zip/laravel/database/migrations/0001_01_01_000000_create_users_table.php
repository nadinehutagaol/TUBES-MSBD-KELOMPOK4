<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('users', function (Blueprint $table) {
        $table->id();
        $table->string('username')->unique();
        $table->string('full_name'); 
        $table->string('email')->unique();
        $table->timestamp('email_verified_at')->nullable(); 
        $table->string('password');
        $table->string('avatar_url')->nullable();
        $table->text('bio')->nullable();
        $table->string('location')->nullable();
        $table->string('website')->nullable();
        $table->string('role')->default('user');
        $table->rememberToken(); 
        $table->timestamps();    
    });
}
    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
