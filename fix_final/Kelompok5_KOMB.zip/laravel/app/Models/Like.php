<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Like extends Model
{
    public $timestamps = true;
    protected $table = 'likes';
    protected $fillable = ['user_id', 'shot_id'];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function shot(): BelongsTo
    {
        return $this->belongsTo(Shot::class);
    }
}